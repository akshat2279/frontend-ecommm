export const addcart= (data:number)=>{
    return{
        type:'addtocart',
        payload : data

    }
}