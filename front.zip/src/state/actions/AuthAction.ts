export const loginuser= (data:any)=>{
    return{
        type:'save',
        payload : data

    }
}