export const plus= (data:any)=>{
    return{
        type:'quantity',
        payload : data

    }
}


