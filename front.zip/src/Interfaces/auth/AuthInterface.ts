export interface ILogin {
    Email: string;
    Password: string;
  }


export  interface IData {
    FirstName: string,
    LastName: string,
    Email: string,
    Phone: number,
    Password: string,
    image?:string
  }


  