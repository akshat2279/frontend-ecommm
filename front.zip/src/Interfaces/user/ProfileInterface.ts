export interface IUser {
    FirstName:string,
    LastName:string,
    Email:string,
    image:string | ArrayBuffer | null | undefined,
    Phone:string
   }