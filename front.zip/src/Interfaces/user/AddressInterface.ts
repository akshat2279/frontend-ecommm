export interface IAddress{
    home:string,
    street:string,
    area:string,
    city:string,
    state:string,
    pincode:string,
    country:string,
    user?:string,
    _id?:number
  }