export interface Icart{
    product:string | undefined | number,
    user:string,
    quantity:number
  }